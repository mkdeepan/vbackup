{
  "groups" : [{
    "id" : 1,
    "text": "status1"
  },
  {
    "id" : 2,
    "text": "customer"
  },
  {
    "id" : 3,
    "text": "vip"
  },
  {
    "id" : 4,
    "text": "admin"
  }]
}